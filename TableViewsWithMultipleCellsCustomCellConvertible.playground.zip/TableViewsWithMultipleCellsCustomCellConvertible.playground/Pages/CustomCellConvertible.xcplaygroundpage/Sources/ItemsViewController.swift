import UIKit


public struct CellDescriptor {
    let cellClass: UITableViewCell.Type
    let reuseIdentifier: String
    let configure: (UITableViewCell) -> ()
    public init<Cell: UITableViewCell>(reuseIdentifier: String, configure: @escaping (Cell) -> ()) {
        self.cellClass = Cell.self
        self.reuseIdentifier = reuseIdentifier
        self.configure = { cell in
            configure(cell as! Cell)
        }
    }
}

public protocol CustomCellConvertible {
    var cellDescriptor: CellDescriptor { get }
}

//extension CustomCellDescriptor {
//    var cellDescriptor: CellDescriptor {
//        return CellDescriptor(reuseIdentifier: "cell") { cell in
//            cell.textLabel?.text = String(describing: self)
//        }
//    }
//
//}

public final class ItemsViewController<Item: CustomCellConvertible>: UITableViewController {
    var items: [Item] = []
    let reuseIdentifier = "Cell"
    var didSelect: (Item) -> () = { _ in }
    var reuseIdentifiers: Set<String> = []
    
    public init(items: [Item]) {
        self.items = items
        super.init(style: .plain)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = items[indexPath.row]
        didSelect(item)
    }
    
    override public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = items[indexPath.row]
        let descriptor = item.cellDescriptor
        let reuseIdentifier = descriptor.reuseIdentifier
        if !reuseIdentifiers.contains(reuseIdentifier) {
            tableView.register(descriptor.cellClass, forCellReuseIdentifier: reuseIdentifier)
            reuseIdentifiers.insert(reuseIdentifier)
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath)
        descriptor.configure(cell)
        return cell
    }
}
